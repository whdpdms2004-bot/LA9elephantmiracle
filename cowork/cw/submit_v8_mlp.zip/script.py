# -*- coding: utf-8 -*-
"""추론 스크립트 (평가 서버가 실행) — 2개 모델 계열의 가중 결합.

의존성: numpy, pandas 만 사용한다. 학습에 쓴 GBDT 는 순수 numpy 배열로 내보내
두었으므로 sklearn 버전과 무관하게 동작한다.

두 계열을 결합한다.
  A) 68피처 모델 (플래툰 인코딩 없음)   -> model/trees_a.npz
  B) 72피처 모델 (플래툰 인코딩 포함)   -> model/trees_b.npz + model/encodings.npz
각각을 자기 캘리브레이션으로 확률화한 뒤, 목표 베이스율 r 을 중심으로 가중 합산한다.

    p = r + w_a (p_a - r) + w_b (p_b - r)

가중치는 두 계열의 예측 공분산 구조와 각 계열의 실측 성능으로부터 산출한 값으로
params.json 에 고정 저장되어 있다. 평가 데이터를 보고 계산하지 않는다.

입력 : ./data/test.csv, ./data/sample_submission.csv
모델 : ./model/trees.npz, ./model/params.json
출력 : ./output/submission.csv

평가 데이터의 다른 행이나 전체 분포를 이용한 계산은 하지 않는다. 각 행은 독립적으로
피처가 만들어지고, 캘리브레이션 상수는 전부 학습 시점에 확정되어 params.json 에
저장된 고정값이다.
"""

import json
import os

import numpy as np
import pandas as pd

ID_COL = "row_id"
TARGET_COL = "control_success"

# =======================================================================
# 1. 피처 생성  (train.py / common.py 와 반드시 동일해야 함)
# =======================================================================

CAT_LEVELS = {
    "top_bottom": ["B", "T"],
    "game_type": ["F", "R"],
    "base_state": ["___", "1__", "_2_", "__3", "12_", "1_3", "_23", "123"],
}

NUM_COLS = [
    "season", "game_month", "game_dayofweek", "inning",
    "balls_before", "strikes_before", "outs_before",
    "run_top_before", "run_bot_before", "run_total_before",
    "score_diff_home", "score_diff_pitcher_team",
    "runner_on_1b", "runner_on_2b", "runner_on_3b", "num_runners_on",
    "home_win_expectancy", "away_win_expectancy", "li",
    "pitcher_id", "batter_id", "pitcher_hand", "batter_hand",
    "pitcher_team_id", "batter_team_id",
    "asof_pitcher_n", "asof_pitcher_success_rate", "asof_pitcher_reverse_rate",
    "asof_pitcher_middle_rate", "asof_pitcher_ball_rate", "asof_pitcher_strike_rate",
    "asof_pitcher_prev1_game_success_rate", "asof_pitcher_prev3_game_success_rate",
    "asof_pitcher_prev5_game_success_rate", "asof_pitcher_prev1_game_middle_rate",
    "asof_pitcher_prev3_game_middle_rate", "asof_pitcher_prev5_game_middle_rate",
    "asof_batter_n", "asof_batter_success_rate", "asof_batter_middle_rate",
    "asof_pitcher_pitchmix_n", "asof_pitcher_fastball_rate",
    "asof_pitcher_breaking_rate", "asof_pitcher_offspeed_rate",
]

DERIVED = [
    "count_state", "is_two_strike", "is_three_ball", "abs_score_diff",
    "pitcher_middle_x_n", "pitcher_form_delta", "pitcher_form_delta5",
    "pitcher_middle_delta", "pitchmix_entropy", "batter_minus_pitcher",
    "log_pitcher_n", "log_batter_n",
]

# 플래툰 스플릿 인코딩 (model/encodings.npz 는 학습 데이터 2019~2024 로만 만들어졌다.
# 평가 데이터의 어떤 행도 인코딩 산출에 쓰이지 않는다.)
ENC_NAMES = ["enc_platoon_split", "enc_batter_split",
             "enc_platoon_n", "enc_batter_split_n"]


def _lookup(keys, table_keys, table_vals, default=np.nan):
    idx = np.clip(np.searchsorted(table_keys, keys), 0, len(table_keys) - 1)
    ok = table_keys[idx] == keys
    out = np.full(len(keys), default, dtype=np.float64)
    out[ok] = table_vals[idx[ok]]
    return out


def encode_rows(pitcher_id, batter_id, pitcher_hand, batter_hand, enc):
    pk = pitcher_id.astype(np.int64) * 10 + batter_hand.astype(np.int64)
    bk = batter_id.astype(np.int64) * 10 + pitcher_hand.astype(np.int64)
    ps = _lookup(pk, enc["p_key"], enc["p_split"])
    bs = _lookup(bk, enc["b_key"], enc["b_split"])
    pn = _lookup(pk, enc["p_key"], enc["p_n"], default=0.0)
    bn = _lookup(bk, enc["b_key"], enc["b_n"], default=0.0)
    return np.stack([ps, bs, np.log1p(pn), np.log1p(bn)], axis=1).astype(np.float32)


def _safe(a):
    return np.nan_to_num(a, nan=0.0, posinf=0.0, neginf=0.0)


def build_features(df, enc=None):
    n = len(df)
    blocks, names = [], []

    num = np.empty((n, len(NUM_COLS)), dtype=np.float32)
    for i, c in enumerate(NUM_COLS):
        num[:, i] = df[c].to_numpy(dtype=np.float32, na_value=np.nan)
    blocks.append(num)
    names += NUM_COLS

    for c, levels in CAT_LEVELS.items():
        v = df[c].astype(str).to_numpy()
        oh = np.zeros((n, len(levels)), dtype=np.float32)
        for j, lv in enumerate(levels):
            oh[:, j] = (v == lv)
        blocks.append(oh)
        names += ["%s=%s" % (c, lv) for lv in levels]

    g = {c: num[:, NUM_COLS.index(c)] for c in NUM_COLS}
    balls, strikes = g["balls_before"], g["strikes_before"]
    pn, bn = g["asof_pitcher_n"], g["asof_batter_n"]
    mix = np.stack([_safe(g["asof_pitcher_fastball_rate"]),
                    _safe(g["asof_pitcher_breaking_rate"]),
                    _safe(g["asof_pitcher_offspeed_rate"])], axis=1)
    mix = np.clip(mix, 1e-6, 1.0)
    ent = -(mix * np.log(mix)).sum(axis=1)

    der = np.stack([
        balls * 3.0 + strikes,
        (strikes >= 2).astype(np.float32),
        (balls >= 3).astype(np.float32),
        np.abs(g["score_diff_pitcher_team"]),
        g["asof_pitcher_middle_rate"] * (pn / (pn + 500.0)),
        g["asof_pitcher_prev3_game_success_rate"] - g["asof_pitcher_success_rate"],
        g["asof_pitcher_prev5_game_success_rate"] - g["asof_pitcher_success_rate"],
        g["asof_pitcher_prev3_game_middle_rate"] - g["asof_pitcher_middle_rate"],
        ent,
        g["asof_batter_success_rate"] - g["asof_pitcher_success_rate"],
        np.log1p(np.nan_to_num(pn, nan=0.0)),
        np.log1p(np.nan_to_num(bn, nan=0.0)),
    ], axis=1).astype(np.float32)
    blocks.append(der)
    names += DERIVED

    if enc is not None:
        blocks.append(encode_rows(
            df["pitcher_id"].to_numpy(np.int64), df["batter_id"].to_numpy(np.int64),
            df["pitcher_hand"].to_numpy(np.int64), df["batter_hand"].to_numpy(np.int64), enc))
        names += ENC_NAMES

    return np.ascontiguousarray(np.concatenate(blocks, axis=1), dtype=np.float32), names


# =======================================================================
# 2. 순수 numpy GBDT 추론
# =======================================================================

def _raw(Xb, trees, t0, t1, baseline):
    feature = trees["feature"]; threshold = trees["threshold"]
    left = trees["left"]; right = trees["right"]
    missing_left = trees["missing_left"].astype(bool)
    is_leaf = trees["is_leaf"].astype(bool)
    value = trees["value"]; offsets = trees["offsets"]

    acc = np.full(Xb.shape[0], baseline, dtype=np.float64)
    for t in range(t0, t1):
        o, o2 = offsets[t], offsets[t + 1]
        f, th = feature[o:o2], threshold[o:o2]
        lf, rt = left[o:o2], right[o:o2]
        ml, il, vl = missing_left[o:o2], is_leaf[o:o2], value[o:o2]
        node = np.zeros(Xb.shape[0], dtype=np.int32)
        active = ~il[node]
        for _ in range(64):
            if not active.any():
                break
            idx = np.flatnonzero(active)
            cur = node[idx]
            v = Xb[idx, f[cur]]
            nan = np.isnan(v)
            go_left = np.where(nan, ml[cur], v <= th[cur])
            node[idx] = np.where(go_left, lf[cur], rt[cur])
            active = ~il[node]
        acc += vl[node]
    return acc


def ensemble_proba(X, trees, chunk=100000):
    """멤버별 확률의 산술 평균 (학습 시 앙상블 방식과 동일)."""
    ms = trees["model_start"]; bl = trees["baselines"]
    K = len(ms) - 1
    n = X.shape[0]
    out = np.zeros(n, dtype=np.float64)
    for s in range(0, n, chunk):
        e = min(n, s + chunk)
        Xb = np.asarray(X[s:e], dtype=np.float64)
        acc = np.zeros(e - s, dtype=np.float64)
        for k in range(K):
            acc += 1.0 / (1.0 + np.exp(-_raw(Xb, trees, int(ms[k]), int(ms[k + 1]), float(bl[k]))))
        out[s:e] = acc / K
    return out


def apply_calibration(p_raw, params):
    """로짓 축소 -> 목표 성공률로 중심 이동 -> 상·하한 클리핑. 상수는 전부 학습 시점 고정값."""
    eps = 1e-6
    p = np.clip(np.asarray(p_raw, dtype=np.float64), eps, 1 - eps)
    lg = np.log(p / (1 - p))
    z = params["logit_scale"] * (lg - params["logit_center_C0"]) + params["logit_target_C1"]
    q = 1.0 / (1.0 + np.exp(-z))
    lo = params["target_rate"] - params["cap"]
    hi = params["target_rate"] + params["cap"]
    return np.clip(q, max(eps, lo), min(1 - eps, hi))


# =======================================================================
# 2b. 순수 numpy MLP 추론 (tanh 은닉 2층 + 시그모이드 출력)
# =======================================================================

def mlp_design(X, blob, chunk_rows=None):
    """72피처 → 84설계열. train_mlp_final.py 의 recipe()/design() 과 동일해야 한다.

    kind 0 = 그대로(NaN→0),  1 = 로짓(0.02~0.98 클립, NaN→0.5),  2 = 결측플래그
    표준화 상수(mu/sd)는 학습 데이터로만 산출된 고정값이다.
    """
    src = blob["col_src"]; kind = blob["col_kind"]
    mu = blob["mu"]; sd = blob["sd"]
    A = np.asarray(X, dtype=np.float64)
    D = np.empty((A.shape[0], len(src)), dtype=np.float64)
    for j in range(len(src)):
        v = A[:, int(src[j])]
        k = int(kind[j])
        if k == 0:
            D[:, j] = np.nan_to_num(v, nan=0.0)
        elif k == 1:
            vv = np.clip(np.nan_to_num(v, nan=0.5), 0.02, 0.98)
            D[:, j] = np.log(vv / (1.0 - vv))
        else:
            D[:, j] = np.isnan(v)
    return ((D - mu) / sd).astype(np.float32)


def mlp_proba(D, blob):
    """시드별 확률의 산술 평균 (학습 시 앙상블 방식과 동일)."""
    n_seeds = int(blob["n_seeds"][0]); n_layers = int(blob["n_layers"][0])
    out = np.zeros(D.shape[0], dtype=np.float64)
    for i in range(n_seeds):
        h = D
        for k in range(n_layers - 1):
            h = np.tanh(h @ blob["s%d_W%d" % (i, k)] + blob["s%d_b%d" % (i, k)])
        z = (h @ blob["s%d_W%d" % (i, n_layers - 1)]
             + blob["s%d_b%d" % (i, n_layers - 1)]).ravel()
        out += 1.0 / (1.0 + np.exp(-np.clip(z.astype(np.float64), -30, 30)))
    return out / n_seeds


def mlp_predict(X, blob, chunk=200000):
    n = X.shape[0]
    out = np.empty(n, dtype=np.float64)
    for s in range(0, n, chunk):
        e = min(n, s + chunk)
        out[s:e] = mlp_proba(mlp_design(X[s:e], blob), blob)
    return out


# =======================================================================
# 3. main
# =======================================================================

def _load(md, name):
    with np.load(os.path.join(md, name)) as z:
        return {k: z[k] for k in z.files}


def main():
    TEST_DIR = "./data"
    MODEL_DIR = "./model"
    OUT_DIR = "./output"

    print("Load model...")
    params = json.load(open(os.path.join(MODEL_DIR, "params.json"), "r", encoding="utf-8"))
    trees_a = _load(MODEL_DIR, "trees_a.npz")
    trees_b = _load(MODEL_DIR, "trees_b.npz")
    enc = _load(MODEL_DIR, "encodings.npz")
    mlp = _load(MODEL_DIR, "mlp.npz")
    pa_par, pb_par, pc_par = params["model_a"], params["model_b"], params["model_c"]
    wa, wb = params["blend_w_a"], params["blend_w_b"]
    u, v = params["blend_u_gbdt"], params["blend_v_mlp"]
    r = params["target_rate"]
    print(" A: %d models / %d trees   B: %d models / %d trees   C(MLP): %d seeds / %d열"
          % (len(trees_a["model_start"]) - 1, len(trees_a["offsets"]) - 1,
             len(trees_b["model_start"]) - 1, len(trees_b["offsets"]) - 1,
             int(mlp["n_seeds"][0]), len(mlp["col_src"])))
    print(" GBDT 내부 w_a=%.4f w_b=%.4f | 상위 u=%.3f v=%.3f | target_rate=%.5f"
          % (wa, wb, u, v, r))

    print("Load test data...")
    test = pd.read_csv(os.path.join(TEST_DIR, "test.csv"), encoding="utf-8-sig")
    sub = pd.read_csv(os.path.join(TEST_DIR, "sample_submission.csv"), encoding="utf-8-sig")
    print(" test=%d  submission=%d" % (len(test), len(sub)))

    print("Build features...")
    X, names = build_features(test, enc)
    assert names == params["feature_names"], "학습/추론 피처 순서 불일치"
    n_a = pa_par["n_features"]
    assert names[:n_a] == params["feature_names_a"], "A계열 피처 접두 불일치"
    print(" features=%d (A는 앞 %d개 사용)" % (X.shape[1], n_a))

    if len(X):
        print("Inference A...")
        p_a = apply_calibration(ensemble_proba(np.ascontiguousarray(X[:, :n_a]), trees_a), pa_par)
        print("Inference B...")
        p_b = apply_calibration(ensemble_proba(X, trees_b), pb_par)
        print("Inference C (MLP)...")
        p_c = apply_calibration(mlp_predict(X, mlp), pc_par)

        # 1단계: 기존 GBDT 2계열 결합 (v7 과 동일, LB 923점 구성)
        p_g = r + wa * (p_a - r) + wb * (p_b - r)
        # 2단계: 그 결과를 하나의 모델로 보고 MLP 와 결합
        p = r + u * (p_g - r) + v * (p_c - r)
        p = np.clip(p, params["floor"], params["ceil"])
        print(" p_a  mean=%.5f sd=%.5f" % (p_a.mean(), p_a.std()))
        print(" p_b  mean=%.5f sd=%.5f" % (p_b.mean(), p_b.std()))
        print(" p_c  mean=%.5f sd=%.5f" % (p_c.mean(), p_c.std()))
        print(" p_g  mean=%.5f sd=%.5f  (GBDT 결합)" % (p_g.mean(), p_g.std()))
        print(" 최종 mean=%.5f sd=%.5f  corr(p_g,p_c)=%.4f"
              % (p.mean(), p.std(),
                 float(np.corrcoef(p_g, p_c)[0, 1]) if len(p_g) > 1 else float("nan")))
    else:
        p = np.array([])

    print("Build submission...")
    pred_map = dict(zip(test[ID_COL].tolist(), p.tolist()))
    values, n_missing = [], 0
    for rid, cur in zip(sub[ID_COL], sub[TARGET_COL]):
        v = pred_map.get(rid)
        if v is None:
            n_missing += 1
            values.append(float(r))
        else:
            values.append(v)
    if n_missing:
        print(" 경고: 예측이 없어 기본값으로 채운 row_id %d건" % n_missing)
    sub[TARGET_COL] = np.clip(values, 0.0, 1.0)

    os.makedirs(OUT_DIR, exist_ok=True)
    out_path = os.path.join(OUT_DIR, "submission.csv")
    sub.to_csv(out_path, index=False, encoding="utf-8")
    print("Saved: %s (rows=%d)" % (out_path, len(sub)))


if __name__ == "__main__":
    main()
